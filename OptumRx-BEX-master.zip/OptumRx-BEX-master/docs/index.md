<div align="center">
    <img src="img/OptumRX.jpg" height="200px" />
</div>
Welcome to your OptumRx BEX documentation page! 🎊 This is the home page and below are some features to help get you started.

## Features
<br/ ><br/ >
<div align="center">
    <img src="img/configure.svg" height="200px" />
</div>
Start configuring and writing your documentation now!
<br/ ><br/ ><br/ ><br/ >

<div align="center">
    <img src="img/collaborate.svg" height="250px" /> 
</div> 
Collaborate with your team to build your documentation to provide your users with the best experience possible.  
<br/ ><br/ ><br/ ><br/ >

<div align="center">
    <img src="img/github.svg" height="175px" />  
</div>
Documentation as code in GitHub allows for anybody to help improve documentation.
<br/ ><br/ >

## Edit 
Get started by editing this page in `docs/index.md` to make it your own. Navigate to the tabs on the top of the site to see the pages that were configured from the builder

## Help
For full documentation visit [this page](https://microsite-docs.optum.com)!
